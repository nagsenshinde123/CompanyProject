package com.example.employee_crud1.Controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmployeeController {
	@GetMapping("/Nagsen")
	public String getEmployee()
	{
		return "List of Employee";
		
	}

}
