/**
 * 
 */
/**
 * @author nagsen.shinde
 *
 */
module TicTacToeGame {
	requires java.desktop;
}