package Project;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class MainClass {

	public static void main(String[] args) {
		 try 
			(FileReader reader = new FileReader("C:\\Users\\nagsen.shinde\\eclipse-workspace\\TicTacToeGame\\src\\Project\\config.properties")){
			  Properties prop=new Properties();
			//  FileInputStream ip= new FileInputStream("C:\\Users\\nagsen.shinde\\eclipse-workspace\\TicTacToeGame\\src\\Project\\config.properties");
			  prop.load(reader);
			  String player1=prop.getProperty("Player1");
			  String player2=prop.getProperty("Player2");
			  System.out.println(player1);
			  System.out.println(player2);
		} catch (IOException e) {
			 
			e.printStackTrace();
		}
		 for(int i=1;i<=2;i++)
		 {
			 Thread thread=new Thread();
		 }
		 Gui gui=new Gui();
		 gui.myGame();
		 

	}

}
