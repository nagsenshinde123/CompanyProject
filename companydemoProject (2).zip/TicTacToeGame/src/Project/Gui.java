package Project;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
public class Gui extends Frame implements ActionListener{
	
	JLabel heading,clockLabel;
	Font font=new Font("",Font.BOLD,30);
	JPanel mainPanel; 
	JButton[] butten=new JButton[9];
	int gameChance[]= {2,2,2,2,2,2,2,2,2};
	int activePlayer=0;
	int a[][]= {{0,1,2},{3,4,5},{6,7,8},{1,4,7},{2,5,8},{0,4,8},{2,4,6}};
	int winner=2;
	 public void myGame()
	 {
		 setTitle(" My TicTacToe Game");
		 setSize(450,450);
		 ImageIcon imageIcon=new ImageIcon("C:/Users/nagsen.shinde/eclipse-workspace/TicTacToeGame/src/Project/Images/download%20(1).png");
		 setIconImage(imageIcon.getImage());
         createGui();
		 setVisible(true);
	 }

	private void setDefaultCloseOperation(int exitOnClose) {
		 setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
	}
	
	public void createGui()
	{
		//this.getcontentPane().setBackground(Color.decode("#54534"));
		this.setLayout(new BorderLayout());
		heading=new JLabel("TicTocToe");
		 
		heading.setFont(font);
		heading.setHorizontalAlignment(SwingConstants.CENTER);
		this.add(heading,BorderLayout.NORTH);
		clockLabel=new JLabel("Clock");
		clockLabel.setFont(font);

		clockLabel.setHorizontalAlignment(SwingConstants.CENTER);
		this.add(clockLabel,BorderLayout.SOUTH);
		
		Thread thread=new Thread()
		{
			public void run()
			{
				try
				{
					while(true)
					{
						String dateTime=new Date().toLocaleString();
						clockLabel.setText(dateTime);
						{
							Thread.sleep(1000);
						}
					}
					
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
			}
			
		};
		
		thread.start();
		mainPanel=new JPanel();
		mainPanel.setLayout(new GridLayout(3,3));
		for(int i=1;i<=9;i++)
		{
			JButton btn=new JButton();
			 
			btn.setBackground(Color.BLACK);
			btn.setFont(font);
			mainPanel.add(btn);
			butten[i-1]=btn;
			 
			btn.addActionListener(this);
			btn.setName(String.valueOf(i-1));
			 
			this.add(mainPanel,BorderLayout.CENTER);
		}
		this.add(mainPanel,BorderLayout.CENTER);
		 
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		//System.out.println("Clicked");
		JButton currentButten=(JButton) e.getSource();
		 
		String StrName=currentButten.getName();
		System.out.println(StrName);
		int name=Integer.parseInt(StrName.trim());
		if(gameChance[name]==2)
		{
			if(activePlayer==1)
			{
			 
				currentButten.setIcon(new ImageIcon("C:/Users/nagsen.shinde/eclipse-workspace/TicTacToeGame/src/Project/Images/images.jpg"));
				gameChance[name]=activePlayer;
				activePlayer=0;
			}
			else
			{
				 
				currentButten.setIcon(new ImageIcon("C:/Users/nagsen.shinde/eclipse-workspace/TicTacToeGame/src/Project/Images/images.png"));
				gameChance[name]=activePlayer;
			    activePlayer=1;
			}
			
			 
			 
		}
		else
		{
			JOptionPane.showMessageDialog(null, "Position already occupied");
		}
		
	}
 
}
