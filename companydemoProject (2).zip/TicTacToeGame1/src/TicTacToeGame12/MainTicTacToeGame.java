package TicTacToeGame12;

import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class MainTicTacToeGame {

	public static void main(String[] args) throws Exception{
		
		 try 
			 {
			  Properties prop=new Properties();
			  FileInputStream ip= new FileInputStream("C:\\Users\\nagsen.shinde\\eclipse-workspace\\TicTacToeGame1\\src\\TicTacToeGame12\\config.properties");
			  prop.load(ip);
			  String player1=prop.getProperty("Player1");
			  String player2=prop.getProperty("Player2");
			  System.out.println(player1);
			  System.out.println(player2);
		} catch (IOException e) {
			 
			e.printStackTrace();
		}
	 
		new TicTacToeGame();

	}

}
