/**
 * 
 */
/**
 * @author nagsen.shinde
 *
 */
module TicTacToeGame1 {
	requires java.desktop;
}