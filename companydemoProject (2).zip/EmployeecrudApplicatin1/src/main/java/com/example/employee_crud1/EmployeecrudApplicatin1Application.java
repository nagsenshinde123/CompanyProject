package com.example.employee_crud1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeecrudApplicatin1Application {

	public static void main(String[] args) {
		SpringApplication.run(EmployeecrudApplicatin1Application.class, args);
	}

}
