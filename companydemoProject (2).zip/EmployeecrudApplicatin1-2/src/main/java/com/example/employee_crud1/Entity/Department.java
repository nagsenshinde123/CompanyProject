package com.example.employee_crud1.Entity;

import java.util.List;
import java.util.UUID;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;  
@Entity(name="department")
public class Department {
	
	@Column(name="Dept_UUID",unique=true)
	private String deptuuid=UUID.randomUUID().toString();
	 
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="Dept_No")
	private int deptNo;
	 
	@Column(name="Dept_Name",unique=true)
	private String deptName;
	
	@Column(name="Dept_Loaction")
	private String deptLocation;
	
	@Column(name="Dept_Head",unique=true)
	private String deptHead;

	public String getDeptuuid() {
		return deptuuid;
	}

	public void setDeptuuid(String deptuuid) {
		this.deptuuid = deptuuid;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public String getDeptLocation() {
		return deptLocation;
	}

	public void setDeptLocation(String deptLocation) {
		this.deptLocation = deptLocation;
	}

	public String getDeptHead() {
		return deptHead;
	}

	public void setDeptHead(String deptHead) {
		this.deptHead = deptHead;
	}
	
	@OneToMany(cascade= {CascadeType.ALL})
	private List<Employee> employee;

	public List<Employee> getEmployee() {
		return employee;
	}

	public void setEmployee(List<Employee> employee) {
		this.employee = employee;
	}
	
	
	 
	
	 
	
	

}
