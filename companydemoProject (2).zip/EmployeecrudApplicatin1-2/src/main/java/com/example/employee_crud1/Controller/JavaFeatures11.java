package com.example.employee_crud1.Controller;

import java.io.IOException;
import java.nio.file.Files;
import java.util.stream.Collectors;

import jakarta.persistence.criteria.Path;

public class JavaFeatures11 {

	public static void main(String[] args) {
		
		String s1="";
		String s2="       ";
		String s3="     dankit";
		String s[]= {"Ankit","Nagsen","Vijay","Sparsh"};
		// isBlank() method
		System.out.println(s1.isBlank()+"\n"+s2.isBlank()+"\n"+s3.isBlank());
		System.out.println(s1.isEmpty()+"\n"+s2.isEmpty()+"\n"+s3.isEmpty());
		
		// lines() method - > returns the stream of strings , which is a collection of all substrings split by lines.
		System.out.println((s1 +"\n"+s2+"\n"+s3).lines().collect(Collectors.toList()));
		
		/* 
		 * strip() -> removes spaces from beginning and end of the string
		 * stripLeading() - > removes spaces from beginning
		 * stripTrailing() - > remove spaces from end
		 * stripIndent() - >  removes spaces from beginning and end of the string in the line .
		 * note -> stripIndent() not introduce in 11.
		 */
		String s4="   ab  c  ";
		System.out.println(s4.strip() +"\n"+s4.stripLeading()+"\n"+s4.stripTrailing()+"\n"+s4.stripIndent());
		
		//System.out.println(s4.trim());
		System.out.println(("                      !                                                                                abc "
				+ "                                                                                    "
				).trim());
		System.out.println(("        !                                                                                              abc "
				+ "                                                                                    "
				).strip());
		
		System.out.println(Character.isWhitespace(5));
		// repeat() - > The repeat method simply repeats the string that many numbers of times as mentioned in the method in the form of an int.
		System.out.println(s[1].repeat(5));
		
		java.nio.file.Path path;
		try {
			path = Files.writeString(Files.createTempFile("Vijay", ".txt"), "This was posted on JD");
			System.out.println(path);
			String ans = Files.readString(path);
			System.out.println(ans);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// TODO Auto-generated method stub

	}

}
