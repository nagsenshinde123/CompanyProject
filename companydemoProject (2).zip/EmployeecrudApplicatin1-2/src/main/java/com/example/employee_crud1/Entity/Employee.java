package com.example.employee_crud1.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

 
@Entity(name="employee")
public class Employee {
	
	@Id
	@GeneratedValue
    @Column(name="Emp_ID")
	private int Emp_ID;
	
	@Column(name="First_Name")
	private String First_Name;
	
	@Column(name="Last_Name")
	private String Last_Name;
	
	@Column(name="Emp_Sal")
	private int Emp_Sal;
 

}
