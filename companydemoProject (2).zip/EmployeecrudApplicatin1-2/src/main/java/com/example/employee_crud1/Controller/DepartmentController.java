package com.example.employee_crud1.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.employee_crud1.Entity.Department;
import com.example.employee_crud1.Entity.Employee;
import com.example.employee_crud1.Repository.DepartmentRepository;

@RestController
public class DepartmentController {
	
	  @Autowired
	  private DepartmentRepository departmentrepo;
	  
	  
	  @GetMapping("/department1")
	  public List<Department> getDepartmentRecord()
	  {
		  return departmentrepo.findAll();
	  }
	  
	  @GetMapping("/department1/")
	  public Department getById(@RequestParam("uuid") String id)
	  {
		  Department existingDpartment=departmentrepo.findByuuid(id);
		  return existingDpartment;
	  }
	  
	  
	  
	  

}
